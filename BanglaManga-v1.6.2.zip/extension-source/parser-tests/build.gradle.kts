plugins {
    kotlin("jvm")
}

kotlin {
    jvmToolchain(17)
    sourceSets {
        main {
            kotlin.srcDir("../src/en/banglamanga/src")
            kotlin.include("**/SiteParsing.kt")
        }
        test {
            kotlin.srcDir("../src/en/banglamanga/test/kotlin")
        }
    }
}

dependencies {
    implementation(libs.kotlin.stdlib)
    testImplementation(libs.junit)
}

tasks.test {
    useJUnit()
}
