#!/usr/bin/env python3
"""Build a Mihon-compatible repository index for this single extension."""

import argparse
import gzip
import json
import re
import shutil
from pathlib import Path
from urllib.parse import quote

from google.protobuf import json_format

import index_pb2


FINGERPRINT_RE = re.compile(r"^[0-9a-f]{64}$")
GITHUB_PART_RE = re.compile(r"^[A-Za-z0-9_.-]+$")
TAG_RE = re.compile(r"^[A-Za-z0-9_.-]+$")


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--metadata", required=True, type=Path, help="Gradle-generated source-info JSON")
    parser.add_argument("--apk", required=True, type=Path, help="Signed release APK")
    parser.add_argument("--icon", required=True, type=Path, help="Extension icon PNG")
    parser.add_argument("--output", required=True, type=Path, help="Directory to write repository files")
    parser.add_argument("--repository", required=True, help="GitHub owner/repository")
    parser.add_argument("--tag", required=True, help="GitHub Release tag containing the APK")
    parser.add_argument("--signing-fingerprint", required=True, help="APK certificate SHA-256, lowercase hex")
    return parser.parse_args()


def main():
    args = parse_args()
    if not args.metadata.is_file():
        raise SystemExit(f"Source metadata not found: {args.metadata}")
    if not args.apk.is_file():
        raise SystemExit(f"Release APK not found: {args.apk}")
    if not args.icon.is_file():
        raise SystemExit(f"Extension icon not found: {args.icon}")

    try:
        owner, repository_name = args.repository.split("/", maxsplit=1)
    except ValueError as error:
        raise SystemExit("--repository must have the form owner/repository") from error
    if not GITHUB_PART_RE.fullmatch(owner) or not GITHUB_PART_RE.fullmatch(repository_name):
        raise SystemExit("--repository contains unsupported characters")
    if not TAG_RE.fullmatch(args.tag):
        raise SystemExit("--tag may contain only letters, digits, dots, underscores and hyphens")

    fingerprint = args.signing_fingerprint.replace(":", "").strip().lower()
    if not FINGERPRINT_RE.fullmatch(fingerprint):
        raise SystemExit("--signing-fingerprint must be a 64-character SHA-256 hex digest")

    with args.metadata.open(encoding="utf-8") as source:
        metadata = json.load(source)

    repository_url = f"https://github.com/{owner}/{repository_name}/raw/repo/index.pb"
    release_url = (
        f"https://github.com/{owner}/{repository_name}/releases/download/"
        f"{quote(args.tag, safe='._-')}/{quote(args.apk.name)}"
    )
    icon_url = f"https://github.com/{owner}/{repository_name}/raw/repo/icons/banglamanga.png"

    sources = [
        index_pb2.Source(
            id=int(source["id"]),
            name=source["name"],
            language=source["lang"],
            homeUrl=source["baseUrl"],
            mirrorUrls=source.get("mirrorUrls", []),
        )
        for source in metadata["sources"]
    ]
    extension = index_pb2.Extension(
        name=metadata["name"],
        packageName=metadata["packageName"],
        resources=index_pb2.Resources(apkUrl=release_url, iconUrl=icon_url),
        extensionLib=metadata["extensionLib"],
        versionCode=int(metadata["versionCode"]),
        versionName=metadata["versionName"],
        contentWarning=int(metadata["contentWarning"]),
        sources=sources,
    )
    index = index_pb2.Index(
        name=metadata["name"],
        badgeLabel="BGM",
        signingKey=fingerprint,
        contact=index_pb2.Contact(website="https://www.banglamanga.com"),
        extensionList=index_pb2.ExtensionList(extensions=[extension]),
    )

    output = args.output
    output.mkdir(parents=True, exist_ok=True)
    icon_output = output / "icons" / "banglamanga.png"
    icon_output.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(args.icon, icon_output)

    repo_metadata = {
        "index_v2": repository_url,
        "meta": {
            "name": metadata["name"],
            "website": "https://www.banglamanga.com",
            "signingKeyFingerprint": fingerprint,
        },
    }
    (output / "repo.json").write_text(
        json.dumps(repo_metadata, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    readable_json = json_format.MessageToJson(
        index,
        preserving_proto_field_name=True,
    )
    (output / "index.json").write_text(readable_json + "\n", encoding="utf-8")
    (output / "index.pb").write_bytes(
        gzip.compress(index.SerializeToString(deterministic=True), mtime=0)
    )

    print(f"Mihon repository URL: {repository_url}")
    print(f"Published APK URL: {release_url}")
    print(f"APK signing fingerprint: {fingerprint}")


if __name__ == "__main__":
    main()
