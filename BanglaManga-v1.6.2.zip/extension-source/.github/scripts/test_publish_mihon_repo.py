import gzip
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

SCRIPT = Path(__file__).with_name("publish_mihon_repo.py")
FINGERPRINT = "0123456789abcdef" * 4


class PublishMihonRepoTests(unittest.TestCase):
    def test_creates_mihon_index_and_metadata_with_stable_urls(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            temp = Path(temp_dir)
            metadata_path = temp / "source-info.json"
            apk_path = temp / "tachiyomi-en.banglamanga-v1.6.1.apk"
            icon_path = temp / "ic_launcher.png"
            output_dir = temp / "repo"
            metadata_path.write_text(
                json.dumps(
                    {
                        "module": "en.banglamanga",
                        "packageName": "eu.kanade.tachiyomi.extension.en.banglamanga",
                        "name": "BanglaManga",
                        "versionCode": 106001,
                        "versionName": "1.6.1",
                        "extensionLib": "1.6",
                        "contentWarning": 2,
                        "sources": [
                            {
                                "id": 662857714798879802,
                                "name": "BanglaManga",
                                "lang": "en",
                                "baseUrl": "https://www.banglamanga.com",
                            }
                        ],
                    }
                ),
                encoding="utf-8",
            )
            apk_path.write_bytes(b"test-apk")
            icon_path.write_bytes(b"test-icon")

            result = subprocess.run(
                [
                    sys.executable,
                    str(SCRIPT),
                    "--metadata",
                    str(metadata_path),
                    "--apk",
                    str(apk_path),
                    "--icon",
                    str(icon_path),
                    "--output",
                    str(output_dir),
                    "--repository",
                    "alice/banglamanga-mihon-en",
                    "--tag",
                    "v1.6.1",
                    "--signing-fingerprint",
                    FINGERPRINT,
                ],
                check=False,
                capture_output=True,
                text=True,
            )

            self.assertEqual(result.returncode, 0, result.stderr)
            from index_pb2 import Index

            repository_url = "https://github.com/alice/banglamanga-mihon-en/raw/repo/index.pb"
            repo = json.loads((output_dir / "repo.json").read_text(encoding="utf-8"))
            self.assertEqual(repo["index_v2"], repository_url)
            self.assertEqual(repo["meta"]["signingKeyFingerprint"], FINGERPRINT)
            self.assertEqual(repo["meta"]["name"], "BanglaManga")

            index = Index()
            index.ParseFromString(gzip.decompress((output_dir / "index.pb").read_bytes()))
            self.assertEqual(index.signingKey, FINGERPRINT)
            self.assertEqual(len(index.extensionList.extensions), 1)
            extension = index.extensionList.extensions[0]
            self.assertEqual(extension.packageName, "eu.kanade.tachiyomi.extension.en.banglamanga")
            self.assertEqual(extension.versionCode, 106001)
            self.assertEqual(
                extension.resources.apkUrl,
                "https://github.com/alice/banglamanga-mihon-en/releases/download/v1.6.1/"
                "tachiyomi-en.banglamanga-v1.6.1.apk",
            )
            self.assertEqual(
                extension.resources.iconUrl,
                "https://github.com/alice/banglamanga-mihon-en/raw/repo/icons/banglamanga.png",
            )
            self.assertEqual(extension.sources[0].language, "en")
            self.assertEqual(extension.sources[0].homeUrl, "https://www.banglamanga.com")
            self.assertEqual((output_dir / "icons" / "banglamanga.png").read_bytes(), b"test-icon")

            readable_index = json.loads((output_dir / "index.json").read_text(encoding="utf-8"))
            self.assertEqual(readable_index["extensionList"]["extensions"][0]["versionName"], "1.6.1")


if __name__ == "__main__":
    unittest.main()
