#!/usr/bin/env python3
"""Prevent publishing a stale or changed Mihon index without a version bump."""

import argparse
import json
from pathlib import Path


def extension_map(index):
    extensions = index.get("extensionList", {}).get("extensions", [])
    return {extension["packageName"]: extension for extension in extensions}


def validate_index_update(previous_index, current_index):
    previous_extensions = extension_map(previous_index)
    current_extensions = extension_map(current_index)

    for package_name, previous in previous_extensions.items():
        current = current_extensions.get(package_name)
        if current is None:
            raise ValueError(
                f"Refusing to remove published extension {package_name}; review removal manually."
            )

        previous_code = int(previous["versionCode"])
        current_code = int(current["versionCode"])
        if current_code < previous_code:
            raise ValueError(
                f"Refusing {package_name}: versionCode {current_code} is older than "
                f"published versionCode {previous_code}."
            )
        if current_code == previous_code and current != previous:
            raise ValueError(
                f"Refusing changed metadata/APK for {package_name} without a versionCode "
                "increase; bump versionCode before publishing."
            )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--previous-index", required=True, type=Path)
    parser.add_argument("--current-index", required=True, type=Path)
    args = parser.parse_args()

    try:
        previous_index = json.loads(args.previous_index.read_text(encoding="utf-8"))
        current_index = json.loads(args.current_index.read_text(encoding="utf-8"))
        validate_index_update(previous_index, current_index)
    except (OSError, json.JSONDecodeError, KeyError, TypeError, ValueError) as error:
        parser.error(str(error))

    print("Index version is newer than, or identical to, the currently published index.")


if __name__ == "__main__":
    main()
