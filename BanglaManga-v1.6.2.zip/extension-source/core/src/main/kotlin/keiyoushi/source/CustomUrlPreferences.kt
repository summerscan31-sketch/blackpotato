package keiyoushi.source

import android.content.SharedPreferences
import android.text.Editable
import android.text.TextWatcher
import android.widget.Button
import androidx.preference.EditTextPreference
import androidx.preference.PreferenceScreen
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull

class CustomUrlPreferences(
    private val preferences: SharedPreferences,
    private val hardcodedUrl: String,
    private val title: String,
    private val dialogMessage: String,
) : FetchableBaseUrl {
    private val prefBaseKey = "overrideBaseUrl"
    private val prefDefaultKey = "defaultBaseUrl"
    private val prefFetchedKey = "fetchedBaseUrl"

    private val defaultUrl: String
        get() = preferences.getString(prefFetchedKey, null) ?: hardcodedUrl

    init {
        val storedDefault = preferences.getString(prefDefaultKey, null)
        if (storedDefault != hardcodedUrl) {
            preferences.edit()
                .putString(prefBaseKey, hardcodedUrl)
                .putString(prefDefaultKey, hardcodedUrl)
                .remove(prefFetchedKey)
                .apply()
        }
    }

    val baseUrl: String
        get() = preferences.getString(prefBaseKey, defaultUrl) ?: defaultUrl

    override fun update(urls: List<String>) {
        val url = urls.first()
        // A typed url stays until the site moves
        if (url == preferences.getString(prefFetchedKey, null)) return
        preferences.edit()
            .putString(prefBaseKey, url)
            .putString(prefFetchedKey, url)
            .apply()
    }

    fun setupPreferenceScreen(screen: PreferenceScreen) {
        EditTextPreference(screen.context).apply {
            key = prefBaseKey
            title = this@CustomUrlPreferences.title
            dialogTitle = this@CustomUrlPreferences.title
            dialogMessage = this@CustomUrlPreferences.dialogMessage

            val currentValue = preferences.getString(prefBaseKey, null)
            summary = currentValue?.takeIf { it.isNotBlank() } ?: defaultUrl
            setDefaultValue(defaultUrl)

            setOnBindEditTextListener { editText ->
                editText.hint = defaultUrl
                editText.setHorizontallyScrolling(true)
                editText.post { editText.selectAll() }
                editText.addTextChangedListener(
                    object : TextWatcher {
                        override fun afterTextChanged(editable: Editable?) {
                            val text = editable?.toString() ?: ""
                            val isValid = text.isBlank() || text.toHttpUrlOrNull() != null
                            editText.rootView.findViewById<Button>(android.R.id.button1)?.isEnabled = isValid
                        }

                        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
                    },
                )
            }

            setOnPreferenceChangeListener { preference, newValue ->
                val text = newValue as String
                val httpUrl = text.toHttpUrlOrNull()
                val isValid = text.isBlank() || httpUrl != null
                if (isValid) {
                    val sanitizedValue = if (text.isBlank()) {
                        defaultUrl
                    } else {
                        val scheme = httpUrl!!.scheme
                        val host = httpUrl.host
                        val port = httpUrl.port
                        val defaultPort = if (scheme == "https") 443 else 80
                        val portStr = if (port == defaultPort) "" else ":$port"
                        "$scheme://$host$portStr"
                    }

                    (preference as EditTextPreference).text = sanitizedValue
                    summary = sanitizedValue

                    preferences.edit()
                        .putString(prefBaseKey, sanitizedValue)
                        .apply()
                }
                false
            }
        }.also(screen::addPreference)
    }
}
