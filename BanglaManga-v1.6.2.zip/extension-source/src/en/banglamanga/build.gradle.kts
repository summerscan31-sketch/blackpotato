import io.github.keiyoushi.gradle.api.ContentWarning

plugins {
    alias(kei.plugins.extension)
}

keiyoushi {
    name = "BanglaManga"
    versionCode = 2
    contentWarning = ContentWarning.MIXED
    libVersion = "1.6"
    source {
        id.set(662857714798879802L)
        baseUrl = "https://www.banglamanga.com"
        lang = "en"
    }
}
