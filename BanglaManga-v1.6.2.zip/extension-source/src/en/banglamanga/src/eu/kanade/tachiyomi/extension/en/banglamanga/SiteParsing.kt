package eu.kanade.tachiyomi.extension.en.banglamanga

import java.net.URI

internal data class SupabaseConfig(
    val url: String,
    val anonKey: String,
)

private val SUPABASE_CONFIG_REGEX = Regex(
    """(https://[a-z0-9-]+\.supabase\.co)["'],[A-Za-z_$][\w$]*=["'](eyJ[A-Za-z0-9._-]+)["']""",
    RegexOption.IGNORE_CASE,
)

internal fun parseSupabaseConfig(scriptText: String): SupabaseConfig? {
    val match = SUPABASE_CONFIG_REGEX.find(scriptText) ?: return null
    val url = match.groupValues[1]
    val anonKey = match.groupValues[2]
    val parsed = runCatching { URI(url) }.getOrNull() ?: return null
    val host = parsed.host?.lowercase() ?: return null

    if (
        !parsed.scheme.equals("https", ignoreCase = true) ||
        !host.endsWith(".supabase.co") ||
        parsed.userInfo != null ||
        parsed.port !in setOf(-1, 443) ||
        parsed.path.isNotEmpty() ||
        anonKey.length < 12
    ) {
        return null
    }

    return SupabaseConfig(url = url, anonKey = anonKey)
}

internal fun hasEnglishTitle(title: String?): Boolean = !title.isNullOrBlank()

internal fun isAllowedImageUrl(url: String?, storageHost: String): Boolean {
    if (url.isNullOrBlank() || url.length > 4096 || storageHost.isBlank()) return false

    val parsed = runCatching { URI(url) }.getOrNull() ?: return false
    val host = parsed.host?.lowercase() ?: return false
    val path = parsed.path ?: return false

    if (
        !parsed.scheme.equals("https", ignoreCase = true) ||
        parsed.userInfo != null ||
        parsed.fragment != null ||
        parsed.port !in setOf(-1, 443) ||
        path.split('/').any { it == "." || it == ".." }
    ) {
        return false
    }

    return when (host) {
        "cdn.banglamanga.com" -> path.startsWith("/chapters/") || path.startsWith("/covers/")
        storageHost.lowercase() -> path.startsWith("/storage/v1/object/public/manga/chapters/") ||
            path.startsWith("/storage/v1/object/public/manga/covers/")
        else -> false
    }
}
