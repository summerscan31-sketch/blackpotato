package eu.kanade.tachiyomi.extension.en.banglamanga

import eu.kanade.tachiyomi.source.model.FilterList
import eu.kanade.tachiyomi.source.model.MangasPage
import eu.kanade.tachiyomi.source.model.Page
import eu.kanade.tachiyomi.source.model.SChapter
import eu.kanade.tachiyomi.source.model.SManga
import eu.kanade.tachiyomi.source.model.SMangaUpdate
import keiyoushi.annotation.Source
import keiyoushi.network.Fetch
import keiyoushi.network.get
import keiyoushi.network.rateLimit
import keiyoushi.source.KeiSource
import keiyoushi.utils.parseAs
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import okhttp3.HttpUrl
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.OkHttpClient
import org.jsoup.Jsoup
import java.io.IOException
import java.time.Instant

@Source
abstract class BanglaManga : KeiSource() {
    override val supportsLatest = true

    @Volatile
    private var cachedApiConfig: SiteApiConfig? = null

    @Volatile
    private var cachedCatalog: CatalogSnapshot? = null

    override fun OkHttpClient.Builder.configureClient() = rateLimit(3) { url ->
        url.host == "www.banglamanga.com" ||
            url.host == "banglamanga.com" ||
            url.host == MEDIA_HOST ||
            url.host.endsWith(".supabase.co")
    }.apply {
        // Do not automatically traverse ad/short-link redirects or cross-domain hops.
        followRedirects(false)
        followSslRedirects(false)
    }

    override suspend fun getPopularManga(page: Int): MangasPage = asMangasPage(loadCatalog("views.desc.nullslast"), page)

    override suspend fun getLatestUpdates(page: Int): MangasPage = asMangasPage(loadCatalog("updated_at.desc.nullslast"), page)

    override suspend fun getSearchMangaList(page: Int, query: String, filters: FilterList): MangasPage {
        val catalog = loadCatalog("updated_at.desc.nullslast")
        val normalizedQuery = query.trim()
        val matches = if (normalizedQuery.isEmpty()) {
            catalog.mangas
        } else {
            catalog.mangas.filter { it.titleEn.orEmpty().contains(normalizedQuery, ignoreCase = true) }
        }
        return asMangasPage(catalog.copy(mangas = matches), page)
    }

    override suspend fun getMangaByUrl(url: HttpUrl): SManga? {
        if (url.host !in SITE_HOSTS) return null
        val candidate = url.queryParameter("manga_id")
            ?: url.queryParameter("id")
            ?: url.pathSegments.lastOrNull()?.takeUnless { it in setOf("", "browse", "read") }
            ?: return null
        val config = siteApiConfig()
        val manga = when {
            UUID_REGEX.matches(candidate) -> fetchMangaById(candidate, config)
            SLUG_REGEX.matches(candidate) -> fetchMangaBySlug(candidate, config)
            else -> null
        } ?: return null
        return manga.takeIf { hasEnglishTitle(it.titleEn) }?.toSManga(config.storageHost)
    }

    override fun getMangaUrl(manga: SManga): String = "$baseUrl/browse"

    override fun getChapterUrl(chapter: SChapter): String = "$baseUrl/read/${chapter.url}"

    override suspend fun fetchMangaUpdate(
        manga: SManga,
        chapters: List<SChapter>,
        fetchDetails: Boolean,
        fetchChapters: Boolean,
    ): SMangaUpdate {
        val config = siteApiConfig()
        val mangaId = manga.url
        val details = if (fetchDetails && UUID_REGEX.matches(mangaId)) {
            fetchMangaById(mangaId, config)
                ?.takeIf { hasEnglishTitle(it.titleEn) }
                ?.toSManga(config.storageHost)
                ?: manga
        } else {
            manga
        }
        val chapterList = if (fetchChapters && UUID_REGEX.matches(mangaId)) {
            fetchChapters(mangaId, config)
        } else {
            chapters
        }
        return SMangaUpdate(details, chapterList)
    }

    override suspend fun getPageList(chapter: SChapter): List<Page> {
        if (!UUID_REGEX.matches(chapter.url)) throw IOException("Chapter not found.")
        val config = siteApiConfig()
        val url = apiUrl(config, "chapters")
            .addQueryParameter("select", CHAPTER_PAGE_FIELDS)
            .addQueryParameter("id", "eq.${chapter.url}")
            .addQueryParameter("limit", "1")
            .build()
        val rows = client.get(url, apiHeaders(config), Fetch.XHR).parseAs<List<ChapterRow>>(SITE_JSON)
        val row = rows.firstOrNull() ?: throw IOException("Chapter not found.")
        if (!isPublicChapter(row)) throw IOException("This chapter is not publicly available.")

        val images = row.pages.orEmpty().mapNotNull { page ->
            page.url?.takeIf { isAllowedImageUrl(it, config.storageHost) }
        }
        if (images.isEmpty()) throw IOException("This chapter has no supported public page images.")
        return images.mapIndexed { index, imageUrl -> Page(index, imageUrl = imageUrl) }
    }

    private suspend fun loadCatalog(order: String): CatalogSnapshot {
        val now = System.currentTimeMillis()
        cachedCatalog?.takeIf { it.order == order && now - it.loadedAt < CATALOG_CACHE_MILLIS }?.let { return it }

        val config = siteApiConfig()
        val mangas = ArrayList<MangaRow>()
        var offset = 0
        while (offset < MAX_INDEX_ROWS) {
            val url = apiUrl(config, "mangas")
                .addQueryParameter("select", MANGA_FIELDS)
                .addQueryParameter("title_en", "not.is.null")
                .addQueryParameter("order", order)
                .addQueryParameter("limit", PAGE_SIZE.toString())
                .addQueryParameter("offset", offset.toString())
                .build()
            val batch = client.get(url, apiHeaders(config), Fetch.XHR).parseAs<List<MangaRow>>(SITE_JSON)
            mangas += batch.filter { hasEnglishTitle(it.titleEn) }
            if (batch.size < PAGE_SIZE) break
            offset += batch.size
        }
        if (offset >= MAX_INDEX_ROWS) throw IOException("The BanglaManga catalog exceeded the safe index limit.")

        return CatalogSnapshot(order, now, config.storageHost, mangas).also { cachedCatalog = it }
    }

    private suspend fun fetchMangaById(id: String, config: SiteApiConfig): MangaRow? {
        if (!UUID_REGEX.matches(id)) return null
        val url = apiUrl(config, "mangas")
            .addQueryParameter("select", MANGA_FIELDS)
            .addQueryParameter("id", "eq.$id")
            .addQueryParameter("limit", "1")
            .build()
        return client.get(url, apiHeaders(config), Fetch.XHR).parseAs<List<MangaRow>>(SITE_JSON).firstOrNull()
    }

    private suspend fun fetchMangaBySlug(slug: String, config: SiteApiConfig): MangaRow? {
        val url = apiUrl(config, "mangas")
            .addQueryParameter("select", MANGA_FIELDS)
            .addQueryParameter("slug", "eq.$slug")
            .addQueryParameter("limit", "1")
            .build()
        return client.get(url, apiHeaders(config), Fetch.XHR).parseAs<List<MangaRow>>(SITE_JSON).firstOrNull()
    }

    private suspend fun fetchChapters(mangaId: String, config: SiteApiConfig): List<SChapter> {
        val chapters = ArrayList<ChapterRow>()
        var offset = 0
        while (offset < MAX_INDEX_ROWS) {
            val url = apiUrl(config, "chapters")
                .addQueryParameter("select", CHAPTER_LIST_FIELDS)
                .addQueryParameter("manga_id", "eq.$mangaId")
                .addQueryParameter("status", "eq.published")
                .addQueryParameter("order", "number.desc.nullslast")
                .addQueryParameter("limit", PAGE_SIZE.toString())
                .addQueryParameter("offset", offset.toString())
                .build()
            val batch = client.get(url, apiHeaders(config), Fetch.XHR).parseAs<List<ChapterRow>>(SITE_JSON)
            chapters += batch.filter(::isPublicChapter)
            if (batch.size < PAGE_SIZE) break
            offset += batch.size
        }
        if (offset >= MAX_INDEX_ROWS) throw IOException("The chapter index exceeded the safe limit.")

        return chapters.map { row ->
            SChapter.create().apply {
                url = row.id
                name = row.number?.let(::chapterName) ?: "One-shot"
                chapter_number = row.number?.toFloat() ?: 0f
                date_upload = row.publishAt?.let(::parseUploadDate) ?: 0L
            }
        }
    }

    private suspend fun siteApiConfig(): SiteApiConfig {
        cachedApiConfig?.let { return it }

        val home = client.get("${baseUrl.trimEnd('/')}/", headers, Fetch.DOCUMENT).use { it.body.string() }
        val document = Jsoup.parse(home, "${baseUrl.trimEnd('/')}/")
        val scriptUrls = document.select("script[src]")
            .mapNotNull { it.absUrl("src").toHttpUrlOrNull() }
            .filter { it.isAllowedSiteBundle() }
            .take(MAX_BUNDLE_SCRIPTS)

        for (scriptUrl in scriptUrls) {
            val script = client.get(scriptUrl, headers, Fetch.XHR).use { it.body.string() }
            val supabase = parseSupabaseConfig(script) ?: continue
            val config = SiteApiConfig(supabase, supabase.url.toHttpUrl().host)
            cachedApiConfig = config
            return config
        }

        throw IOException("BanglaManga's public catalog configuration could not be found.")
    }

    private fun HttpUrl.isAllowedSiteBundle(): Boolean = scheme == "https" &&
        host in SITE_HOSTS &&
        encodedPath.startsWith("/assets/") &&
        encodedPath.endsWith(".js", ignoreCase = true)

    private fun apiUrl(config: SiteApiConfig, table: String): HttpUrl.Builder = config.supabase.url.toHttpUrl()
        .newBuilder()
        .addPathSegments("rest/v1")
        .addPathSegment(table)

    private fun apiHeaders(config: SiteApiConfig) = headers.newBuilder()
        .set("apikey", config.supabase.anonKey)
        .set("Authorization", "Bearer ${config.supabase.anonKey}")
        .set("Accept", "application/json")
        .build()

    private fun asMangasPage(catalog: CatalogSnapshot, page: Int): MangasPage {
        val safePage = page.coerceAtLeast(1)
        val start = (safePage - 1) * MANGA_PAGE_SIZE
        val pageRows = catalog.mangas.drop(start).take(MANGA_PAGE_SIZE)
        return MangasPage(
            pageRows.map { it.toSManga(catalog.storageHost) },
            start + pageRows.size < catalog.mangas.size,
        )
    }

    private fun MangaRow.toSManga(storageHost: String): SManga {
        val sourceStatus = status
        val sourceWorkType = workType?.takeIf { it.isNotBlank() }
        val sourceFormat = format?.takeIf { it.isNotBlank() }
        val sourceGenres = genres.orEmpty().filter { it.isNotBlank() }.joinToString(", ").takeIf { it.isNotBlank() }

        return SManga.create().apply {
            title = titleEn.orEmpty()
            url = id
            thumbnail_url = coverUrl?.takeIf { isAllowedImageUrl(it, storageHost) }
            genre = sourceGenres
            description = buildList {
                add("This listing has an English title. The chapter image language is not identified in the public catalog.")
                sourceWorkType?.let { add("Type: $it") }
                sourceFormat?.let { add("Format: $it") }
                sourceStatus?.takeIf { it.isNotBlank() }?.let { add("Status: $it") }
            }.joinToString("\n\n")
            when (sourceStatus?.lowercase()) {
                "ongoing" -> status = SManga.ONGOING
                "completed" -> status = SManga.COMPLETED
            }
        }
    }

    private fun isPublicChapter(chapter: ChapterRow): Boolean {
        if (chapter.status != "published") return false
        val publishedAt = chapter.publishAt?.let { runCatching { Instant.parse(it) }.getOrNull() }
        return publishedAt == null || !publishedAt.isAfter(Instant.now())
    }

    private fun parseUploadDate(value: String): Long = runCatching { Instant.parse(value).toEpochMilli() }.getOrDefault(0L)

    private fun chapterName(number: Double): String = if (number == 0.0) "One-shot" else "Chapter ${number.toString().removeSuffix(".0")}"

    private data class SiteApiConfig(
        val supabase: SupabaseConfig,
        val storageHost: String,
    )

    private data class CatalogSnapshot(
        val order: String,
        val loadedAt: Long,
        val storageHost: String,
        val mangas: List<MangaRow>,
    )

    @Serializable
    private data class MangaRow(
        val id: String,
        @SerialName("title_en") val titleEn: String? = null,
        val slug: String? = null,
        @SerialName("cover_url") val coverUrl: String? = null,
        val genres: List<String>? = null,
        val status: String? = null,
        @SerialName("work_type") val workType: String? = null,
        val format: String? = null,
    )

    @Serializable
    private data class ChapterRow(
        val id: String,
        @SerialName("manga_id") val mangaId: String? = null,
        val number: Double? = null,
        val status: String? = null,
        @SerialName("publish_at") val publishAt: String? = null,
        val pages: List<ChapterPage>? = null,
    )

    @Serializable
    private data class ChapterPage(
        val url: String? = null,
    )

    companion object {
        private const val MEDIA_HOST = "cdn.banglamanga.com"
        private const val PAGE_SIZE = 500
        private const val MANGA_PAGE_SIZE = 30
        private const val MAX_INDEX_ROWS = 10_000
        private const val MAX_BUNDLE_SCRIPTS = 12
        private const val CATALOG_CACHE_MILLIS = 5 * 60_000L
        private const val MANGA_FIELDS = "id,title_en,slug,cover_url,genres,status,work_type,format,views,updated_at,created_at"
        private const val CHAPTER_LIST_FIELDS = "id,manga_id,number,status,publish_at"
        private const val CHAPTER_PAGE_FIELDS = "id,manga_id,number,status,publish_at,pages"

        private val SITE_HOSTS = setOf("www.banglamanga.com", "banglamanga.com")
        private val UUID_REGEX = Regex("[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[1-8][0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}")
        private val SLUG_REGEX = Regex("[a-zA-Z0-9-]{2,200}")
        private val SITE_JSON = Json { ignoreUnknownKeys = true }
    }
}
